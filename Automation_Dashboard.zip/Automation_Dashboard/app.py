import re
import pdfplumber
import pandas as pd
import os
from flask import Flask, render_template, request, redirect, url_for, send_file

app = Flask(__name__)

UPLOAD_FOLDER = "uploads"
EXPORT_FOLDER = "exports"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(EXPORT_FOLDER, exist_ok=True)

# Master file path for storing all history
MASTER_HISTORY_FILE = os.path.join(EXPORT_FOLDER, "invoice_history.csv")

@app.route("/")
def home_page():
    history_data = []
    unique_items = []
    unique_customers = []
    unique_cities = []

    if os.path.exists(MASTER_HISTORY_FILE):
        df = pd.read_csv(MASTER_HISTORY_FILE)

        # Filters from request
        invoice_filter = request.args.get("invoice", "").strip()
        item_filter = request.args.get("item", "").strip()
        start_date = request.args.get("start_date", "")
        end_date = request.args.get("end_date", "")
        customer_filter = request.args.get("customer", "").strip()
        city_filter = request.args.get("city", "").strip()

        # Apply filters
        if invoice_filter:
            df = df[df["Invoice Number"].astype(str).str.contains(invoice_filter, case=False, na=False)]
        if item_filter:
            df = df[df["Item"].astype(str) == item_filter]
        if start_date:
            df = df[pd.to_datetime(df["Date"], errors="coerce") >= pd.to_datetime(start_date)]
        if end_date:
            df = df[pd.to_datetime(df["Date"], errors="coerce") <= pd.to_datetime(end_date)]
        if customer_filter:
            df = df[df["Customer"].astype(str) == customer_filter]
        if city_filter:
            df = df[df["City"].astype(str) == city_filter]

        history_data = df.to_dict("records")

        # Get unique items for dropdowns
        if "Item" in df.columns:
            unique_items = sorted(df["Item"].dropna().unique())
        if "Customer" in df.columns:
            unique_customers = sorted(df["Customer"].dropna().unique())
        if "City" in df.columns:
            unique_cities = sorted(df["City"].dropna().unique())

    return render_template("index.html", history=history_data, unique_items=unique_items, unique_customers=unique_customers, unique_cities=unique_cities)

@app.route("/upload", methods=["POST"])
def upload():
    file = request.files["file"]
    filepath = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(filepath)

    if file.filename.endswith(".pdf"):
        extracted_data = {}
        full_text = ""
        tables_df = pd.DataFrame()

        with pdfplumber.open(filepath) as pdf:
            for page in pdf.pages:
                full_text += (page.extract_text() or "") + "\n"

                # Extract tables for detailed item data
                page_tables = page.extract_tables()
                if page_tables:
                    for table in page_tables:
                        df_table = pd.DataFrame(table[1:], columns=table[0])
                        tables_df = pd.concat([tables_df, df_table], ignore_index=True)

        # Regex patterns for summary fields
        patterns = {
            "Invoice Number": r"INVOICE #(\d+)",
            "Date": r"Date:\s*([\d\-A-Za-z]+)",
            "Customer": r"Customer:\s*(.+?)(?=\s*Address|$)",
            "City": r"Address:\s*(.+?)(?:\s+Date|$)",
            "Subtotal": r"Subtotal\s*([\d.]+)",
            "GST (18%)": r"GST \(18%\)\s*([\d.]+)",
            "Total": r"(?:Subtotal\s*[\d.]+\s+GST\s*\(\d+%\)\s*[\d.]+\s+)Total\s*([\d.]+)"
        }

        # Extract summary fields and clean
        for key, pattern in patterns.items():
            match = re.search(pattern, full_text, re.IGNORECASE)
            value = match.group(1).strip() if match else "N/A"
            if key in ["Customer", "City"]:
                value = value.replace("(", "").replace(")", "").strip()
            extracted_data[key] = value

        summary_df = pd.DataFrame([extracted_data])

        if not tables_df.empty:
            # Remove rows containing Subtotal/GST/Total inside item tables
            tables_df = tables_df[~tables_df.apply(
                lambda row: row.astype(str).str.contains("Subtotal|GST|Total", case=False, na=False).any(),
                axis=1
            )]

            # Repeat summary for each item row
            summary_repeated = pd.concat([summary_df] * len(tables_df), ignore_index=True)
            extracted_df = pd.concat([summary_repeated, tables_df.reset_index(drop=True)], axis=1)

            # Convert numeric fields
            num_cols = ["Quantity", "Amount"]
            for col in num_cols:
                if col in extracted_df.columns:
                    extracted_df[col] = pd.to_numeric(extracted_df[col], errors="coerce").fillna(0)

            # Distribute Subtotal, GST, Total proportionally based on Quantity
            total_cols = ["Subtotal", "GST (18%)", "Total"]
            extracted_df['TotalQtyPerInvoice'] = extracted_df.groupby('Invoice Number')['Quantity'].transform('sum')
            for col in total_cols:
                extracted_df[col] = pd.to_numeric(extracted_df[col], errors="coerce").fillna(0)
                extracted_df[col] = (extracted_df[col] * (extracted_df['Quantity'] / extracted_df['TotalQtyPerInvoice'])).round(2)

            extracted_df.drop(columns=['TotalQtyPerInvoice'], inplace=True)

        else:
            # No item table found, create single row
            extracted_df = pd.DataFrame([{
                "Invoice Number": extracted_data["Invoice Number"],
                "Date": extracted_data["Date"],
                "Customer": extracted_data["Customer"],
                "City": extracted_data["City"],
                "Subtotal": float(extracted_data.get("Subtotal", 0)),
                "GST (18%)": float(extracted_data.get("GST (18%)", 0)),
                "Total": float(extracted_data.get("Total", 0)),
                "Item": "N/A",
                "Quantity": 0,
                "Rate": 0,
                "Amount": 0
            }])

        # Append to master CSV safely
        append_mode = os.path.exists(MASTER_HISTORY_FILE)
        extracted_df.to_csv(MASTER_HISTORY_FILE, mode='a', header=not append_mode, index=False)

    return redirect(url_for("home_page"))


@app.route("/dashboard")
def dashboard_page():
    history_data = []
    unique_items = []
    unique_customers = []
    unique_cities = []
    if os.path.exists(MASTER_HISTORY_FILE):
        df = pd.read_csv(MASTER_HISTORY_FILE)
        history_data = df.to_dict('records')

        if "Item" in df.columns:
            unique_items = sorted(df["Item"].dropna().unique())
        if "Customer" in df.columns:
            unique_customers = sorted(df["Customer"].dropna().unique())
        if "City" in df.columns:
            unique_cities = sorted(df["City"].dropna().unique())

    return render_template("dashboard.html", history_data=history_data, unique_items=unique_items, unique_customers=unique_customers, unique_cities=unique_cities)


@app.route("/download")
def download():
    if os.path.exists(MASTER_HISTORY_FILE):
        return send_file(MASTER_HISTORY_FILE, as_attachment=True)
    return "History file not found.", 404

if __name__ == "__main__":
    app.run(debug=True, port=5000)
